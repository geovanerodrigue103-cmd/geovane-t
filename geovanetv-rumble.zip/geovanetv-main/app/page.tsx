import { StreamHeader } from "@/components/stream-header"
import { StreamPlayer } from "@/components/stream-player"
import { LiveChat } from "@/components/live-chat"

export default function Page() {
  return (
    <div className="flex min-h-screen flex-col bg-[#0f0f12] text-white">
      <StreamHeader />
      <main className="mx-auto flex w-full max-w-[1400px] flex-1 flex-col gap-4 p-4 lg:flex-row">
        <div className="flex flex-col gap-3 lg:flex-[3]">
          <StreamPlayer />
        </div>
        <div className="lg:flex-1">
          <LiveChat />
        </div>
      </main>
    </div>
  )
}
