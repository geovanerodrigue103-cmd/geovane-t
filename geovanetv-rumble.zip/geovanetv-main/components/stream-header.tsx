"use client"

import { useEffect, useState } from "react"
import { createClient } from "@/lib/supabase/client"

export function StreamHeader() {
  const [viewers, setViewers] = useState<number>(1)

  useEffect(() => {
    const supabase = createClient()
    const userId = Math.random().toString(36).slice(2)

    const channel = supabase.channel("stream-presence", {
      config: { presence: { key: userId } },
    })

    channel
      .on("presence", { event: "sync" }, () => {
        const state = channel.presenceState()
        setViewers(Object.keys(state).length)
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
          await channel.track({ online_at: new Date().toISOString() })
        }
      })

    return () => {
      supabase.removeChannel(channel)
    }
  }, [])

  return (
    <header className="flex items-center justify-between bg-gradient-to-br from-[#1f1c2c] to-[#928dab] px-5 py-4 shadow-lg">
      <h1 className="flex items-center gap-2.5 text-2xl font-bold tracking-wide text-white">
        📺 GEOVANE TV
        <span className="animate-pulse rounded bg-[#ff0033] px-2 py-1 text-xs font-bold text-white">
          AO VIVO
        </span>
      </h1>
      <div className="flex items-center gap-1.5 rounded-full bg-black/40 px-3 py-1.5 text-sm">
        👁 <span>{viewers}</span> espectador(es)
      </div>
    </header>
  )
}
