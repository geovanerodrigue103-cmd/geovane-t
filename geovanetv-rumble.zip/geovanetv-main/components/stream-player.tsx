export function StreamPlayer() {
  return (
    <section className="flex flex-col gap-3">
      <div className="relative aspect-video w-full overflow-hidden rounded-lg bg-black shadow-2xl">
        <iframe
          title="Transmissão Principal - Geovane TV"
          src="https://rumble.com/embed/v7g5eu0/?pub=4qmzq2"
          allow="autoplay; fullscreen"
          allowFullScreen
          className="absolute inset-0 h-full w-full border-0"
        />
      </div>
      <div className="rounded-lg bg-[#18181c] p-4">
        <h2 className="text-lg font-semibold text-[#e1e1e6]">Transmissão Principal - Geovane TV</h2>
      </div>
    </section>
  )
}
