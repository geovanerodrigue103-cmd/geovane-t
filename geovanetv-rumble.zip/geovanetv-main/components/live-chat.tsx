"use client"

import { useCallback, useEffect, useRef, useState, type FormEvent, type KeyboardEvent } from "react"
import { createClient } from "@/lib/supabase/client"

type ChatMessage = {
  id: string
  username: string
  content: string
  created_at: string
}

function getStoredUsername() {
  if (typeof window === "undefined") return ""
  const stored = window.localStorage.getItem("geovane-tv-username")
  if (stored) return stored
  const generated = `Visitante${Math.floor(1000 + Math.random() * 9000)}`
  window.localStorage.setItem("geovane-tv-username", generated)
  return generated
}

export function LiveChat() {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState("")
  const [username, setUsername] = useState("")
  const [status, setStatus] = useState<"connecting" | "online" | "error">("connecting")
  const [sending, setSending] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const supabaseRef = useRef(createClient())

  useEffect(() => {
    setUsername(getStoredUsername())
  }, [])

  useEffect(() => {
    const supabase = supabaseRef.current
    let active = true

    async function loadHistory() {
      const { data, error } = await supabase
        .from("chat_messages")
        .select("id, username, content, created_at")
        .order("created_at", { ascending: true })
        .limit(100)

      if (!active) return
      if (error) {
        setStatus("error")
        return
      }
      setMessages(data as ChatMessage[])
    }

    loadHistory()

    const channel = supabase
      .channel("public:chat_messages")
      .on(
        "postgres_changes",
        { event: "INSERT", schema: "public", table: "chat_messages" },
        (payload) => {
          const next = payload.new as ChatMessage
          setMessages((prev) => (prev.some((m) => m.id === next.id) ? prev : [...prev, next]))
        },
      )
      .subscribe((channelStatus) => {
        if (channelStatus === "SUBSCRIBED") setStatus("online")
        else if (channelStatus === "CHANNEL_ERROR" || channelStatus === "TIMED_OUT") setStatus("error")
      })

    return () => {
      active = false
      supabase.removeChannel(channel)
    }
  }, [])

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  const sendMessage = useCallback(async () => {
    const content = input.trim()
    const name = username.trim() || "Visitante"
    if (content === "" || sending) return

    setSending(true)
    setInput("")

    const { error } = await supabaseRef.current
      .from("chat_messages")
      .insert({ username: name.slice(0, 40), content: content.slice(0, 500) })

    if (error) {
      setInput(content)
    }
    setSending(false)
  }, [input, username, sending])

  function handleSubmit(e: FormEvent) {
    e.preventDefault()
    sendMessage()
  }

  function handleKeyDown(e: KeyboardEvent<HTMLInputElement>) {
    if (e.key === "Enter" && !e.nativeEvent.isComposing && e.keyCode !== 229) {
      e.preventDefault()
      sendMessage()
    }
  }

  function handleUsernameChange(value: string) {
    setUsername(value)
    if (typeof window !== "undefined") {
      window.localStorage.setItem("geovane-tv-username", value)
    }
  }

  return (
    <section className="flex h-[500px] flex-col rounded-lg bg-[#18181c] shadow-2xl lg:h-auto">
      <header className="flex items-center justify-between gap-2 rounded-t-lg border-b border-[#29292e] bg-[#202024] px-4 py-3">
        <span className="font-semibold">Chat ao Vivo</span>
        <span className="flex items-center gap-1.5 text-xs text-[#a1a1aa]">
          <span
            className={`h-2 w-2 rounded-full ${
              status === "online" ? "bg-[#22c55e]" : status === "error" ? "bg-[#ef4444]" : "bg-[#eab308]"
            }`}
            aria-hidden="true"
          />
          {status === "online" ? "Conectado" : status === "error" ? "Erro de conexão" : "Conectando..."}
        </span>
      </header>

      <div className="flex flex-1 flex-col gap-2.5 overflow-y-auto p-4" aria-live="polite">
        {messages.length === 0 ? (
          <p className="text-sm text-[#a1a1aa]">Seja o primeiro a enviar uma mensagem!</p>
        ) : (
          messages.map((msg) => (
            <div key={msg.id} className="break-words rounded-md bg-[#202024] px-3 py-2 text-sm">
              <span className="mr-1.5 font-bold text-[#00a8ff]">{msg.username}:</span>
              {msg.content}
            </div>
          ))
        )}
        <div ref={messagesEndRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-2 rounded-b-lg border-t border-[#29292e] bg-[#202024] p-3">
        <div className="flex items-center gap-2">
          <label htmlFor="chat-username" className="sr-only">
            Seu nome
          </label>
          <input
            id="chat-username"
            type="text"
            value={username}
            onChange={(e) => handleUsernameChange(e.target.value)}
            placeholder="Seu nome"
            autoComplete="off"
            maxLength={40}
            className="w-40 rounded border border-[#29292e] bg-[#121214] px-2.5 py-1.5 text-sm text-white outline-none focus:border-[#00a8ff]"
          />
        </div>
        <div className="flex gap-2">
          <label htmlFor="chat-input" className="sr-only">
            Digite sua mensagem
          </label>
          <input
            id="chat-input"
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={handleKeyDown}
            placeholder="Digite sua mensagem..."
            autoComplete="off"
            maxLength={500}
            className="flex-1 rounded border border-[#29292e] bg-[#121214] p-2.5 text-white outline-none focus:border-[#00a8ff]"
          />
          <button
            type="submit"
            disabled={sending}
            className="rounded bg-[#00a8ff] px-4 py-2.5 font-bold text-white transition-colors hover:bg-[#0086cc] disabled:cursor-not-allowed disabled:opacity-60"
          >
            Enviar
          </button>
        </div>
      </form>
    </section>
  )
}
